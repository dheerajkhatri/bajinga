#include <bits/stdc++.h>
using namespace std;

bool flags[100005];

int apac1(int k){
	int n = 100005;		
	flags[1]=0;
	flags[2]=0;

	for(int i=3;i<=n;i++){
		int upperPow = ceil(log2(i));		
		int diff = pow(2,upperPow)-i;		
		if(!diff)flags[i] = 0;
		else flags[i] = !flags[diff];
	}

	return flags[k];
}

void init(){
	memset(flags,0,100005);
	return;
}

int main(int argc,char* argv[]){
	
	string line;	
	ifstream filereader;
	filereader.open("A-small-attempt0.in");

	ofstream out;
	out.open("output.txt");

	getline(filereader,line);
	int t = stoi(line),k;

	init();

	for(int i=0;i<t;i++){
		getline(filereader,line);
		k = stoi(line);
		out<<"Case #"<<i+1<<": "<<apac1(k)<<endl;
	}

	filereader.close();
	out.close();
	return 0;
}